import java.util.ArrayList;
import java.util.Scanner;

public class Assignment6Q2 {

	// method
	public static void union(ArrayList<Integer> list1, ArrayList<Integer> list2) {
		ArrayList<Integer> list3 = new ArrayList<>(); // the superlist/union
		
		list3.addAll(list1); 
		list3.addAll(list2);

		System.out.println(list3);
		
	}

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		ArrayList<Integer> list1 = new ArrayList<>();
		ArrayList<Integer> list2 = new ArrayList<>();

		System.out.println("Enter 5 integers");
		for (int i = 0; i < 5; i++) {
			// System.out.println("Enter an integer");
			int n = keyboard.nextInt(); // look at delimeter settings for spacebar input
			list1.add(n);
		}
		System.out.println("Enter an integer");
		for (int i = 0; i < 5; i++) {
			// System.out.println("Enter an integer");
			int n = keyboard.nextInt();
			list2.add(n);
		}

		// System.out.println(list1);
		// System.out.println(list2);

		union(list1, list2);

	}

}
