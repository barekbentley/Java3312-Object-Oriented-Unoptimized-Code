

/*Write a test program that creates an Account with annual interest rate 1.5%, balance 1000, id 1122, and name George. 
Deposit $30, $40, and $50 to the account and withdraw $5, $4, and $2 from the account. 
Print an account summary that shows account holder name, interest rate, balance, and all transactions*/

public class TestingAssignment6Q1 {
	
	public static void main(String[] args) {
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		Account firstAccount = new Account(1122, 1000, "George"); // creates an account with id 1122 and balance 1000 and a name of "George" 
		firstAccount.setUniqueAnnualInterestRate(1.5); // should set interest rate to 1.5% //enter x.x%
		
		
		
		
		
		firstAccount.deposit(30, "I was told to add 30"); 
		firstAccount.deposit(40, "I was told to add 40");
		firstAccount.deposit(50, "I was told to add 50 ");
		
		firstAccount.withdraw(5,"I was told to take 5");
		firstAccount.withdraw(4,"I was told to take 4");
		firstAccount.withdraw(2,"I was told to take 2");
		
		
		System.out.println("------------------------------------------");
		
		
		System.out.println(firstAccount.getTransactions());
		
		System.out.println("------------------------------------------");
		System.out.println(firstAccount.getName()+": Is the name of the aaccount holder");
		System.out.println(firstAccount.accessAnnualInterestRate()+"%: is the annual interest rate");
		
		System.out.println("------------------------------------------");
		for(int i = 0; i < firstAccount.transactions.size();i++ ) { 
		System.out.println(firstAccount.transactions.get(i).getAmountOfBalance()+": Is the balance as of this transaction hitting the account");
		System.out.println(firstAccount.transactions.get(i).getAmountOfTransaction()+" dollars: Amount of Transaction");
		System.out.println(firstAccount.transactions.get(i).getTransactionDescription()+": Description/Reason for Transaction");
		System.out.println(firstAccount.transactions.get(i).getDateOfTransaction()+": Date of Transaction");
		
		System.out.println(firstAccount.transactions.get(i).getTypeOfTransaction()+": Type of transaction");
		System.out.println("------------------------------------------");
		}

		//System.out.print(firstAccount.transactions.get(0).get
		/*for (int i = firstAccount.transactions.indexOf(0); i < firstAccount.transactions.size()-1 ; i++)
		      System.out.print(firstAccount.transactions.get(i).getTypeOfTransaction() + " ");
		    System.out.println();*/
		
		//System.out.println(firstAccount.transactions.get(5).getTypeOfTransaction());
		
	}

}
