import java.util.Date;
//Step3

public class Transaction {

	private Date dateOfTransaction;
	private char typeOfTransaction;
	private double amountOfTransaction;
	private double amountOfBalance;
	private String transactionDescription;

	public Transaction(char type, double amount, double balance, String description)

	{ // step3
		this.dateOfTransaction = new Date();
		this.typeOfTransaction = type;
		this.amountOfBalance = balance;
		this.amountOfTransaction = amount;
		this.transactionDescription = description;

	}
	
	public String toString(){
		return ("Transaction Date" + dateOfTransaction+ "Type of Transaction" +typeOfTransaction); //optimized with prof
		
	}
		
	

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public char getTypeOfTransaction() {
		return typeOfTransaction;
	}

	public void setTypeOfTransaction(char typeOfTransaction) {
		this.typeOfTransaction = typeOfTransaction;
	}

	public double getAmountOfTransaction() {
		return amountOfTransaction;
	}

	public void setAmountOfTransaction(double amountOfTransaction) {
		this.amountOfTransaction = amountOfTransaction;
	}

	public double getAmountOfBalance() {
		return amountOfBalance;
	}

	public void setAmountOfBalance(double amountOfBalance) {
		this.amountOfBalance = amountOfBalance;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;

	}

}
