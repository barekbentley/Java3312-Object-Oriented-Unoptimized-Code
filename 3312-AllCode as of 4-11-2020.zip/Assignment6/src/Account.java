import java.util.ArrayList;
import java.util.Date;

public class Account {

	private int id = 0;
	private double balance = 0;
	private double annualInterestRate = 0;
	private Date dateCreated;
	private String name;

	ArrayList<Transaction> transactions = new ArrayList<>();

	public Account() {
		dateCreated = new Date();

	}

	void name(String name) { // #step 1
		this.name = name;
	}

	Account(int uniqueId, double uniqueBalance) {
		this();
		this.id = uniqueId;
		this.balance = uniqueBalance;
	}

	Account(int id, double balance, String name) { // step 2
		this(id, balance);
		this.name = name;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	int accessId() {
		return id;
	}

	double accessBalance() {
		return balance;
	}

	double accessAnnualInterestRate() {
		return annualInterestRate;
	}

	void setUniqueId(int newId) {
		this.id = newId;
	}

	void setUniqueBalance(double newBalance) {
		this.balance = newBalance;
	}

	void setUniqueAnnualInterestRate(double newAnnualInterestRate) {
		this.annualInterestRate = newAnnualInterestRate;
	}

	Date accessDateCreated() {
		return dateCreated;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	double getMonthlyInterestRate() {
		return (annualInterestRate / 12);
	}

	void withdraw(double withdrawAmount, String description) {
		this.balance = balance - withdrawAmount;
		// add a withdraw to transactions arrayList: step 4
		Transaction wTransaction = new Transaction('W', withdrawAmount, this.balance, description);
		transactions.add(wTransaction);

	}

	void deposit(double depositAmount, String description) {
		this.balance = balance + depositAmount;
		// add a Deposit to transactions arrayList: step 4
		Transaction dTransaction = new Transaction('D', depositAmount, this.balance, description);
		transactions.add(dTransaction);
	}

}
