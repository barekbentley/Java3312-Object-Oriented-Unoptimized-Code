
public class Circle {

	public Circle() {
		// TODO Auto-generated constructor stub
	}

}
