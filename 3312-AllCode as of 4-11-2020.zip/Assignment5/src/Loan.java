
public class Loan {

	public Loan() {
		// TODO Auto-generated constructor stub
	}

}
