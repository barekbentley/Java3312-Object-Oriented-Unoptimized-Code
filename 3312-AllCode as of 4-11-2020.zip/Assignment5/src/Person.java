
public class Person {
	public String Name;

	public Person() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	} // Part a is done
}
