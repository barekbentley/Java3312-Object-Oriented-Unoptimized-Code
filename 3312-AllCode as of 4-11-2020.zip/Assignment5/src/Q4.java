import java.util.ArrayList;
import java.util.Date;

public class Q4 {

	public Q4() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Loan testLoan = new Loan();
		Date testDate = new Date();
		String testString = "testString";
		CircleWithPrivateDataFields testCircleObject = new CircleWithPrivateDataFields(2);

		ArrayList<Object> list = new ArrayList<Object>();

		list.add(testLoan);
		list.add(testString);
		list.add(testDate);
		list.add(testCircleObject);

		for (int i = 0; i < list.size(); i++)
			System.out.print(list.get(i).toString() + ", ");
		System.out.println();
		System.out.println("Clarification:");
		System.out.println("Object @memory address because I have not declared the .toString to print anything else");

	}

}
