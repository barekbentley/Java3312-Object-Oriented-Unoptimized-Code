import java.util.ArrayList;

public class TestintA5 {

	public TestintA5() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student one = new Student();
		one.setName("student1");

		Student two = new Student();
		two.setName("student2");

		Student three = new Student();
		three.setName("student3");

		Student four = new Student();
		four.setName("student4");

		Student five = new Student();
		five.setName("student5");

		Student six = new Student();
		six.setName("student6");

		Student seven = new Student();
		seven.setName("student7");

		Student eight = new Student();
		eight.setName("student8");

		Student nine = new Student();
		nine.setName("student9");

		Student ten = new Student();
		ten.setName("student10");

		Student taskC = new Student();
		taskC.setName("studentTaskC");

		Student taskD = new Student();
		taskD.setName("studentTaskD");

		ArrayList<Student> studentList = new ArrayList<Student>() {
			{
				add(one); // task b
				add(two);
				add(three);
				add(four);
				add(five);
				add(six);
				add(seven);
				add(eight);
				add(nine);
				add(ten);
			}

		};

		studentList.add(taskC);// task c
		studentList.add(0, taskD); // task D

		System.out.println(studentList.size() + ": Number of students after two appends"); // task E

		studentList.remove(two); // taskF

		System.out.println(studentList.size() + ": Number of students after a .remove"); // test taskF

		System.out.println(studentList.get(10).getName() + ": The student I retrieved for task G"); // task G

		System.out.println(studentList.contains(two)
				+ ": Which is correct becuase I checked for the studentd I removed in task F"); // task H

		for (int i = 0; i < studentList.size(); i++)
			System.out.print(studentList.get(i).getName() + " ");
		System.out.println(); // task I

		studentList.clear(); // task J
		for (int i = 0; i < studentList.size(); i++)
			System.out.print(studentList.get(i).getName() + " ");
		System.out.println(); // check task j
		System.out.println(
				"The line above is blank beucase I printed a blank list, becuase I cleared it with a loop. This is a check statement.");
	}

}
