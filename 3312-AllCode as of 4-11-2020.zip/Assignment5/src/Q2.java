import java.util.ArrayList;

public class Q2 {

	public Q2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> cityList = new ArrayList<String>();
		cityList.add("Dallas"); // a
		cityList.add("Dallas");
		cityList.add("Houston");
		cityList.add("Dallas");
		System.out.println(cityList+": This is to check the entire list");

		cityList.remove("Dallas");
		System.out.println(cityList+": After to the .remove(Dallas) was written");

		for (int i = 0; i < cityList.size(); i++)
			cityList.remove("Dallas");
		System.out.println("");
		System.out.println(cityList + ": After the loop to remove Dallas is written"); // Task b

	}

}
