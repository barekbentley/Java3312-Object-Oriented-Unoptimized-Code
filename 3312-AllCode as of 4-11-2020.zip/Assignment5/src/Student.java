
public class Student extends Person {

	public Student() {
		// TODO Auto-generated constructor stub
	}

}
