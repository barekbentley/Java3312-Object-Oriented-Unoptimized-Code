import java.util.*;

public class TestingAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account testDefaultAccount = new Account(); 
		Account testAccountWithArgumentsAccount = new Account(1122, 20000);
		
		//testing account constructors with arguments passed and some methods
		//methods tested: balance, date, ID
		System.out.println("Test Account with Arguments: Balance should be 20000 "+ testAccountWithArgumentsAccount.accessBalance());
		System.out.println("Testing Account with Arguments: ID shoud be 1122 "+ testAccountWithArgumentsAccount.accessId());
		System.out.println("Testing Account with Arguments: Date should be "+testAccountWithArgumentsAccount.accessDateCreated());
		
		//testing account constructor with no arguments passed
		System.out.println("Testing Account with No Arguments: Date should be "+testDefaultAccount.accessDateCreated());
		
		//testing setters //testing accessors by accessing got information
		testDefaultAccount.setUniqueId(123);
		testDefaultAccount.setUniqueBalance(456);
		testDefaultAccount.setUniqueAnnualInterestRate(6.9);
		
		System.out.println("ID should be 123: "+testDefaultAccount.accessId());
		System.out.println("Balance should be 456: "+testDefaultAccount.accessBalance());
		System.out.println("Annual Interest Rate should be 6.9: "+testDefaultAccount.accessAnnualInterestRate());
		
		
		//testing methods that return void and get monthly
		
		System.out.println("Monthly Rate should equal 6.9/12 = .575: "+ testDefaultAccount.getMonthlyInterestRate());
		testDefaultAccount.deposit(4000); //deposit 4000
		testDefaultAccount.withdraw(2000); //withdraw 2000
		System.out.println("After using the deposit and withdraw methods using 4000 as deposit and 2000 as a withdraw the total should be 2456: "+
		testDefaultAccount.accessBalance());
		
		
		
		
	}
}

