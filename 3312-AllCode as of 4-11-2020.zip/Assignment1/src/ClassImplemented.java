import java.util.*;

public class ClassImplemented {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account firstAccount = new Account(1122, 20000); // creates an account with id 1122 and balance 20000

		firstAccount.setUniqueAnnualInterestRate(4.5); // should set interest rate to 4.5% //enter x.x%

		firstAccount.withdraw(2500);
		firstAccount.deposit(3000);

		System.out.println("The account balance is:$ " + firstAccount.accessBalance());
		System.out.println("The monthly interest is: " + firstAccount.getMonthlyInterestRate() + "%");
		System.out.println("The account was created on this day: " + firstAccount.accessDateCreated());

	}

}

class Account {

	private int id = 0; // #1
	private double balance = 0; // #2
	private double annualInterestRate = 0; // #3
	private Date dateCreated; // #4

	Account() { // #5
		dateCreated = new Date();
	}

	Account(int uniqueId, double uniqueBalance) { // #6
		id = uniqueId;
		balance = uniqueBalance;

		dateCreated = new Date();
	}

	int accessId() { // #7
		return id; 
	}

	double accessBalance() { // #7
		return balance;
	}

	double accessAnnualInterestRate() { // #7
		return annualInterestRate;
	}

	void setUniqueId(int newId) { // #7 //Why is this void? Does it need to be something else?
		id = newId;
	}

	void setUniqueBalance(double newBalance) { // #7
		balance = newBalance;
	}

	void setUniqueAnnualInterestRate(double newAnnualInterestRate) { // #7
		annualInterestRate = newAnnualInterestRate;
	}

	Date accessDateCreated() { // #8
		return dateCreated;
	}

	double getMonthlyInterestRate() {
		return (annualInterestRate / 12); // I think this is what step #9 implies? ((1+Rate)^(1/12)-1)*12
	}

	void withdraw(double withdrawAmount) { // #10 hmmm. Does this need to be a "setter" method? //why is this void?
		balance = balance - withdrawAmount;
	}

	void deposit(double depositAmount) { // #11 hmmm. Does this need to be a "setter" method?
		balance = balance + depositAmount;// why is this void?

	}
}