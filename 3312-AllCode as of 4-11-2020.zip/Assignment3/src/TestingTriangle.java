public class TestingTriangle {
	public static void main(String[] args) {
		// System.out.println("Hello World");
		Triangle testTriangleNoArgs = new Triangle();

		Triangle testTriangleWithArgs = new Triangle(1, 1.5, 1, "yellow", true);

		System.out.println("The following are for the rubric requested example:");
		System.out.println();
		// This tests if I can get information from a triangle with arguments
		System.out.println(testTriangleWithArgs.getArea() + " units squared is the area"); // area
		System.out.println(testTriangleWithArgs.getPerimeter() + " units is the Perimeter"); // Perimeter
		System.out.println(testTriangleWithArgs.getColor() + " is the color");// Color
		System.out.println(testTriangleWithArgs.isFilled() + " T/F of filling");
		
		System.out.println(testTriangleNoArgs.

		System.out.println("The following is testing for all the Methods. Not explicitly mentioned in the rubric");
		// testing toString method for triangle with arguments
		System.out.println();
		System.out.println(testTriangleWithArgs.toString());

		// This tests if I can set information with a triangle with no arguments
		testTriangleNoArgs.setSide1(5.0); // setting side 1
		testTriangleNoArgs.setSide2(5.0); // setting side 2
		testTriangleNoArgs.setSide3(5.0);// setting side 3
		testTriangleNoArgs.setColor("Red"); // setting the color to red
		testTriangleNoArgs.setFilled(false); // setting the filling to NOT filled

		// testing to see if I get information with a triangle with args I've manually
		// set with setter methods
		System.out.println(testTriangleNoArgs.getSide1() + " is side 1"); // getting sides
		System.out.println(testTriangleNoArgs.getSide2() + " is side 2");
		System.out.println(testTriangleNoArgs.getSide3() + " is side 3");

		System.out.println(testTriangleNoArgs.getArea() + " is the area");// getting area

		System.out.println(testTriangleNoArgs.getColor() + " is the color");// getting color
		System.out.println(testTriangleNoArgs.getPerimeter() + " is the Perimeter");// Getting Perimeter

		System.out.println(testTriangleNoArgs.isFilled() + " T/F if filled or not"); // checking to see if is filled

		// testing some methods from SimpleGeometric object

		System.out.println(testTriangleNoArgs.getDateCreated() + " get date when objectNoArgs was created");
		System.out.println(testTriangleWithArgs.getDateCreated() + " get date when objectWithArgs was created");
	}

}
