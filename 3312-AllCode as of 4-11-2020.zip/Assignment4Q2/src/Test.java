
public class Test {

	 public static void main(String[] args) {
		 Object fruit = new Fruit();
		// Object apple = (Apple)fruit; //cannot cast apple as a fruit, becuase it s a
			// fruit
			Object apple = new Fruit();
		 }
		 }

		 class Apple extends Fruit {
		 }

		 class Fruit {


}
